"""Web entry point (written by make_web.py)."""
import asyncio
import pygame  # pygbag loads the packages it sees imported here, so pygame must be named

from game.app import run_web

asyncio.run(run_web())
